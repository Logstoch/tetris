# Tetris [![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fcgolden15%2Ftetris&count_bg=%2379C83D&title_bg=%23555555&icon=html5.svg&icon_color=%23E7E7E7&title=hits&edge_flat=false)](https://hits.seeyoufarm.com)
Robust version of Twitch Tetris. Created to bypass school blocks &amp; to add a few updates of my own. To host yourself, just clone the repo and publish to github pages or fork it as a repl.


## Known Issues:
If you fix them, create a pull request for it. You will be credited.
- High scores leaderboard doesn't work
- Weird rendering issue with blocks at top of screen

## Screenshots
![image](https://user-images.githubusercontent.com/61284764/154609080-7dc112c4-e174-4a02-bf28-7b670019c8dc.png)
![image](https://user-images.githubusercontent.com/61284764/154609127-860ddd1c-3500-4b4f-89bd-0c8e13876cde.png)

